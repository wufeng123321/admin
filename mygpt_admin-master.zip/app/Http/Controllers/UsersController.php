<?php

namespace App\Http\Controllers;

use App\Models\LoginModel;
use App\Models\User;
use App\Models\UsersModel;
use App\SubApps\Cms\Models\CouponConfig;
use Encore\Admin\Grid;
use Illuminate\Auth\Events\Login;
use Illuminate\Http\Request;

class UsersController extends Controller
{
    protected $title = '优惠券配置';

    public function getRandom(){
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $str = '';
        for ($i = 0; $i < 16; $i++) {
            $str .= $characters[mt_rand(0, strlen($characters) - 1)];
        }
        return $str;
    }

    public function createNewClient(Request $request){
        // 创建新的账号
        try{
            $last = UsersModel::latest()->first();
            $level = $request->input('level','0');
            $item = new UsersModel();
            $account = 'user'.sprintf("%05d",((int)($last->id)+1));
            $password = $request->input('password',$this->getRandom());
            $item->account = $account;
            $item->password = $password;
            $item->level = $level;
            $item->save();
            return [
                'err' => 0,
                'msg' => 'success',
                'result' => [
                    'account' => $item->account,
                    'password' => $item->password,
                ]
            ];
        } catch (\Exception $e){
            return [
              'err' => 9998,
              'msg' => $e->getMessage()
            ];
        }
    }

    public function login(Request $request){
        // 登录
        try{
            $account = $request->input('account','');
            $password = $request->input('password','');
            $device_sn = $request->input('device_sn','');
            $item = UsersModel::where('account',$account)->first();
            if(isset($item) && !empty($item)){
                if($item->password === $password){
                    $now_time = time();
                    $create_time = strtotime($item->created_at);
                    if($now_time-$create_time < ((int)config('users_rule.validity_period') * 86400)){
                        $arr = LoginModel::where('account',$account)->get();
                        $length = count($arr->toArray());
                        $verify_length = !in_array($device_sn,$arr->pluck('device_sn')->toArray()) ? $length + 1 : $length;
                        if($verify_length <= config('users_rule.level_counts_map')[(int)($item->level)]){
                            $now_length = $length;
                            if(!in_array($device_sn,$arr->pluck('device_sn')->toArray())){
                                $new_item = new LoginModel();
                                $new_item->account = $account;
                                $new_item->device_sn = $device_sn;
                                $new_item->save();
                                $now_length += 1;
                            }
                            return [
                                'err' => 0,
                                'msg' => 'success',
                                'result' => $now_length
                            ];
                        } else {
                            return [
                                'err' => 9998,
                                'msg' => '登录设备数量超过上限，请先退出不用的客户端登录'
                            ];
                        }
                    } else {
                      return [
                        'err' => 9998,
                        'msg' => '该账号已过期'
                      ];
                    }
                }else {
                    return [
                        'err' => 9998,
                        'msg' => '密码错误'
                    ];
                }
            }else {
                return [
                    'err' => 9998,
                    'msg' => '没有找到对应的账号信息'
                ];
            }
        }catch (\Exception $e){
            return [
                'err' => 9998,
                'msg' => $e->getMessage()
            ];
        }
    }

    public function loginOut(Request $request){
        // 退出登录
        try{
            $account = $request->input('account');
            $device_sn = $request->input('device_sn');
            $item = LoginModel::where('account',$account)->where('device_sn',$device_sn)->first();
            if(isset($item)){
                $item->delete();
            }
            return [
                'err' => 0,
                'msg' => 'success'
            ];
        } catch (\Exception $e){
            return [
                'err' => 9998,
                'msg' => $e->getMessage()
            ];
        }
    }

    public function modify(Request $request){
        // 更新账号信息
        $password = $request->input('password','');
        $level = $request->input('level','');
        $account = $request->input('account','');
        $item = UsersModel::where('account',$account)->first();
        if($item->exists){
            if($password !== ''){
                $item->password = $password;
            }
            if($level !== ''){
                $item->level = $level;
            }
            $item->save();
            return [
                'err' => 0,
                'msg' => 'success'
            ];
        }else{
            return [
              'err' => 9998,
              'msg' => '查无此人'
            ];
        }
    }
}
