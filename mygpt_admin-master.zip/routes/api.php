<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('create_client',[\App\Http\Controllers\UsersController::class,'createNewClient']);
Route::post('login',[\App\Http\Controllers\UsersController::class,'login']);
Route::post('login_out',[\App\Http\Controllers\UsersController::class,'loginOut']);
Route::post('modify',[\App\Http\Controllers\UsersController::class,'modify']);
