<?php

return [
    'level_counts_map' => [
        0 => 3,
        1 => 5
    ],
    'validity_period' => env('VALIDITY_PERIOD'),
];
